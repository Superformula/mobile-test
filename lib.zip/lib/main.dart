import 'package:flutter/material.dart';
import 'package:superformula_mobile_test/presentation/core/app_widget.dart';

void main() {
  runApp(const SuperFormulaChallengeApp());
}
