// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides

part of 'qr_seed.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more informations: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

/// @nodoc
class _$QrSeedTearOff {
  const _$QrSeedTearOff();

  _QrSeed call(
      {required QrSeedData data, required QrSeedExpirationDate expireDate}) {
    return _QrSeed(
      data: data,
      expireDate: expireDate,
    );
  }
}

/// @nodoc
const $QrSeed = _$QrSeedTearOff();

/// @nodoc
mixin _$QrSeed {
  QrSeedData get data => throw _privateConstructorUsedError;
  QrSeedExpirationDate get expireDate => throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $QrSeedCopyWith<QrSeed> get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $QrSeedCopyWith<$Res> {
  factory $QrSeedCopyWith(QrSeed value, $Res Function(QrSeed) then) =
      _$QrSeedCopyWithImpl<$Res>;
  $Res call({QrSeedData data, QrSeedExpirationDate expireDate});
}

/// @nodoc
class _$QrSeedCopyWithImpl<$Res> implements $QrSeedCopyWith<$Res> {
  _$QrSeedCopyWithImpl(this._value, this._then);

  final QrSeed _value;
  // ignore: unused_field
  final $Res Function(QrSeed) _then;

  @override
  $Res call({
    Object? data = freezed,
    Object? expireDate = freezed,
  }) {
    return _then(_value.copyWith(
      data: data == freezed
          ? _value.data
          : data // ignore: cast_nullable_to_non_nullable
              as QrSeedData,
      expireDate: expireDate == freezed
          ? _value.expireDate
          : expireDate // ignore: cast_nullable_to_non_nullable
              as QrSeedExpirationDate,
    ));
  }
}

/// @nodoc
abstract class _$QrSeedCopyWith<$Res> implements $QrSeedCopyWith<$Res> {
  factory _$QrSeedCopyWith(_QrSeed value, $Res Function(_QrSeed) then) =
      __$QrSeedCopyWithImpl<$Res>;
  @override
  $Res call({QrSeedData data, QrSeedExpirationDate expireDate});
}

/// @nodoc
class __$QrSeedCopyWithImpl<$Res> extends _$QrSeedCopyWithImpl<$Res>
    implements _$QrSeedCopyWith<$Res> {
  __$QrSeedCopyWithImpl(_QrSeed _value, $Res Function(_QrSeed) _then)
      : super(_value, (v) => _then(v as _QrSeed));

  @override
  _QrSeed get _value => super._value as _QrSeed;

  @override
  $Res call({
    Object? data = freezed,
    Object? expireDate = freezed,
  }) {
    return _then(_QrSeed(
      data: data == freezed
          ? _value.data
          : data // ignore: cast_nullable_to_non_nullable
              as QrSeedData,
      expireDate: expireDate == freezed
          ? _value.expireDate
          : expireDate // ignore: cast_nullable_to_non_nullable
              as QrSeedExpirationDate,
    ));
  }
}

/// @nodoc

class _$_QrSeed implements _QrSeed {
  const _$_QrSeed({required this.data, required this.expireDate});

  @override
  final QrSeedData data;
  @override
  final QrSeedExpirationDate expireDate;

  @override
  String toString() {
    return 'QrSeed(data: $data, expireDate: $expireDate)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other is _QrSeed &&
            (identical(other.data, data) ||
                const DeepCollectionEquality().equals(other.data, data)) &&
            (identical(other.expireDate, expireDate) ||
                const DeepCollectionEquality()
                    .equals(other.expireDate, expireDate)));
  }

  @override
  int get hashCode =>
      runtimeType.hashCode ^
      const DeepCollectionEquality().hash(data) ^
      const DeepCollectionEquality().hash(expireDate);

  @JsonKey(ignore: true)
  @override
  _$QrSeedCopyWith<_QrSeed> get copyWith =>
      __$QrSeedCopyWithImpl<_QrSeed>(this, _$identity);
}

abstract class _QrSeed implements QrSeed {
  const factory _QrSeed(
      {required QrSeedData data,
      required QrSeedExpirationDate expireDate}) = _$_QrSeed;

  @override
  QrSeedData get data => throw _privateConstructorUsedError;
  @override
  QrSeedExpirationDate get expireDate => throw _privateConstructorUsedError;
  @override
  @JsonKey(ignore: true)
  _$QrSeedCopyWith<_QrSeed> get copyWith => throw _privateConstructorUsedError;
}
