// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides

part of 'qr_seed_failure.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more informations: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

/// @nodoc
class _$QrSeedFailureTearOff {
  const _$QrSeedFailureTearOff();

  _QrSeedFailure unexpected() {
    return const _QrSeedFailure();
  }
}

/// @nodoc
const $QrSeedFailure = _$QrSeedFailureTearOff();

/// @nodoc
mixin _$QrSeedFailure {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() unexpected,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? unexpected,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_QrSeedFailure value) unexpected,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_QrSeedFailure value)? unexpected,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $QrSeedFailureCopyWith<$Res> {
  factory $QrSeedFailureCopyWith(
          QrSeedFailure value, $Res Function(QrSeedFailure) then) =
      _$QrSeedFailureCopyWithImpl<$Res>;
}

/// @nodoc
class _$QrSeedFailureCopyWithImpl<$Res>
    implements $QrSeedFailureCopyWith<$Res> {
  _$QrSeedFailureCopyWithImpl(this._value, this._then);

  final QrSeedFailure _value;
  // ignore: unused_field
  final $Res Function(QrSeedFailure) _then;
}

/// @nodoc
abstract class _$QrSeedFailureCopyWith<$Res> {
  factory _$QrSeedFailureCopyWith(
          _QrSeedFailure value, $Res Function(_QrSeedFailure) then) =
      __$QrSeedFailureCopyWithImpl<$Res>;
}

/// @nodoc
class __$QrSeedFailureCopyWithImpl<$Res>
    extends _$QrSeedFailureCopyWithImpl<$Res>
    implements _$QrSeedFailureCopyWith<$Res> {
  __$QrSeedFailureCopyWithImpl(
      _QrSeedFailure _value, $Res Function(_QrSeedFailure) _then)
      : super(_value, (v) => _then(v as _QrSeedFailure));

  @override
  _QrSeedFailure get _value => super._value as _QrSeedFailure;
}

/// @nodoc

class _$_QrSeedFailure implements _QrSeedFailure {
  const _$_QrSeedFailure();

  @override
  String toString() {
    return 'QrSeedFailure.unexpected()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) || (other is _QrSeedFailure);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() unexpected,
  }) {
    return unexpected();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? unexpected,
    required TResult orElse(),
  }) {
    if (unexpected != null) {
      return unexpected();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_QrSeedFailure value) unexpected,
  }) {
    return unexpected(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_QrSeedFailure value)? unexpected,
    required TResult orElse(),
  }) {
    if (unexpected != null) {
      return unexpected(this);
    }
    return orElse();
  }
}

abstract class _QrSeedFailure implements QrSeedFailure {
  const factory _QrSeedFailure() = _$_QrSeedFailure;
}
