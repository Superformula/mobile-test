// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides

part of 'failures.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more informations: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

/// @nodoc
class _$ValueFailureTearOff {
  const _$ValueFailureTearOff();

  Empty<T> empty<T>({required T failedValue}) {
    return Empty<T>(
      failedValue: failedValue,
    );
  }

  MultilineString<T> multilineString<T>({required String failedValue}) {
    return MultilineString<T>(
      failedValue: failedValue,
    );
  }

  InvalidLenghtString<T> invalidLenghtString<T>({required String failedValue}) {
    return InvalidLenghtString<T>(
      failedValue: failedValue,
    );
  }

  InvalidIsoFormat<T> invalidIsoFormat<T>({required String failedValue}) {
    return InvalidIsoFormat<T>(
      failedValue: failedValue,
    );
  }
}

/// @nodoc
const $ValueFailure = _$ValueFailureTearOff();

/// @nodoc
mixin _$ValueFailure<T> {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(T failedValue) empty,
    required TResult Function(String failedValue) multilineString,
    required TResult Function(String failedValue) invalidLenghtString,
    required TResult Function(String failedValue) invalidIsoFormat,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(T failedValue)? empty,
    TResult Function(String failedValue)? multilineString,
    TResult Function(String failedValue)? invalidLenghtString,
    TResult Function(String failedValue)? invalidIsoFormat,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(Empty<T> value) empty,
    required TResult Function(MultilineString<T> value) multilineString,
    required TResult Function(InvalidLenghtString<T> value) invalidLenghtString,
    required TResult Function(InvalidIsoFormat<T> value) invalidIsoFormat,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(Empty<T> value)? empty,
    TResult Function(MultilineString<T> value)? multilineString,
    TResult Function(InvalidLenghtString<T> value)? invalidLenghtString,
    TResult Function(InvalidIsoFormat<T> value)? invalidIsoFormat,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ValueFailureCopyWith<T, $Res> {
  factory $ValueFailureCopyWith(
          ValueFailure<T> value, $Res Function(ValueFailure<T>) then) =
      _$ValueFailureCopyWithImpl<T, $Res>;
}

/// @nodoc
class _$ValueFailureCopyWithImpl<T, $Res>
    implements $ValueFailureCopyWith<T, $Res> {
  _$ValueFailureCopyWithImpl(this._value, this._then);

  final ValueFailure<T> _value;
  // ignore: unused_field
  final $Res Function(ValueFailure<T>) _then;
}

/// @nodoc
abstract class $EmptyCopyWith<T, $Res> {
  factory $EmptyCopyWith(Empty<T> value, $Res Function(Empty<T>) then) =
      _$EmptyCopyWithImpl<T, $Res>;
  $Res call({T failedValue});
}

/// @nodoc
class _$EmptyCopyWithImpl<T, $Res> extends _$ValueFailureCopyWithImpl<T, $Res>
    implements $EmptyCopyWith<T, $Res> {
  _$EmptyCopyWithImpl(Empty<T> _value, $Res Function(Empty<T>) _then)
      : super(_value, (v) => _then(v as Empty<T>));

  @override
  Empty<T> get _value => super._value as Empty<T>;

  @override
  $Res call({
    Object? failedValue = freezed,
  }) {
    return _then(Empty<T>(
      failedValue: failedValue == freezed
          ? _value.failedValue
          : failedValue // ignore: cast_nullable_to_non_nullable
              as T,
    ));
  }
}

/// @nodoc

class _$Empty<T> implements Empty<T> {
  const _$Empty({required this.failedValue});

  @override
  final T failedValue;

  @override
  String toString() {
    return 'ValueFailure<$T>.empty(failedValue: $failedValue)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other is Empty<T> &&
            (identical(other.failedValue, failedValue) ||
                const DeepCollectionEquality()
                    .equals(other.failedValue, failedValue)));
  }

  @override
  int get hashCode =>
      runtimeType.hashCode ^ const DeepCollectionEquality().hash(failedValue);

  @JsonKey(ignore: true)
  @override
  $EmptyCopyWith<T, Empty<T>> get copyWith =>
      _$EmptyCopyWithImpl<T, Empty<T>>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(T failedValue) empty,
    required TResult Function(String failedValue) multilineString,
    required TResult Function(String failedValue) invalidLenghtString,
    required TResult Function(String failedValue) invalidIsoFormat,
  }) {
    return empty(failedValue);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(T failedValue)? empty,
    TResult Function(String failedValue)? multilineString,
    TResult Function(String failedValue)? invalidLenghtString,
    TResult Function(String failedValue)? invalidIsoFormat,
    required TResult orElse(),
  }) {
    if (empty != null) {
      return empty(failedValue);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(Empty<T> value) empty,
    required TResult Function(MultilineString<T> value) multilineString,
    required TResult Function(InvalidLenghtString<T> value) invalidLenghtString,
    required TResult Function(InvalidIsoFormat<T> value) invalidIsoFormat,
  }) {
    return empty(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(Empty<T> value)? empty,
    TResult Function(MultilineString<T> value)? multilineString,
    TResult Function(InvalidLenghtString<T> value)? invalidLenghtString,
    TResult Function(InvalidIsoFormat<T> value)? invalidIsoFormat,
    required TResult orElse(),
  }) {
    if (empty != null) {
      return empty(this);
    }
    return orElse();
  }
}

abstract class Empty<T> implements ValueFailure<T> {
  const factory Empty({required T failedValue}) = _$Empty<T>;

  T get failedValue => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $EmptyCopyWith<T, Empty<T>> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $MultilineStringCopyWith<T, $Res> {
  factory $MultilineStringCopyWith(
          MultilineString<T> value, $Res Function(MultilineString<T>) then) =
      _$MultilineStringCopyWithImpl<T, $Res>;
  $Res call({String failedValue});
}

/// @nodoc
class _$MultilineStringCopyWithImpl<T, $Res>
    extends _$ValueFailureCopyWithImpl<T, $Res>
    implements $MultilineStringCopyWith<T, $Res> {
  _$MultilineStringCopyWithImpl(
      MultilineString<T> _value, $Res Function(MultilineString<T>) _then)
      : super(_value, (v) => _then(v as MultilineString<T>));

  @override
  MultilineString<T> get _value => super._value as MultilineString<T>;

  @override
  $Res call({
    Object? failedValue = freezed,
  }) {
    return _then(MultilineString<T>(
      failedValue: failedValue == freezed
          ? _value.failedValue
          : failedValue // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$MultilineString<T> implements MultilineString<T> {
  const _$MultilineString({required this.failedValue});

  @override
  final String failedValue;

  @override
  String toString() {
    return 'ValueFailure<$T>.multilineString(failedValue: $failedValue)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other is MultilineString<T> &&
            (identical(other.failedValue, failedValue) ||
                const DeepCollectionEquality()
                    .equals(other.failedValue, failedValue)));
  }

  @override
  int get hashCode =>
      runtimeType.hashCode ^ const DeepCollectionEquality().hash(failedValue);

  @JsonKey(ignore: true)
  @override
  $MultilineStringCopyWith<T, MultilineString<T>> get copyWith =>
      _$MultilineStringCopyWithImpl<T, MultilineString<T>>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(T failedValue) empty,
    required TResult Function(String failedValue) multilineString,
    required TResult Function(String failedValue) invalidLenghtString,
    required TResult Function(String failedValue) invalidIsoFormat,
  }) {
    return multilineString(failedValue);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(T failedValue)? empty,
    TResult Function(String failedValue)? multilineString,
    TResult Function(String failedValue)? invalidLenghtString,
    TResult Function(String failedValue)? invalidIsoFormat,
    required TResult orElse(),
  }) {
    if (multilineString != null) {
      return multilineString(failedValue);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(Empty<T> value) empty,
    required TResult Function(MultilineString<T> value) multilineString,
    required TResult Function(InvalidLenghtString<T> value) invalidLenghtString,
    required TResult Function(InvalidIsoFormat<T> value) invalidIsoFormat,
  }) {
    return multilineString(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(Empty<T> value)? empty,
    TResult Function(MultilineString<T> value)? multilineString,
    TResult Function(InvalidLenghtString<T> value)? invalidLenghtString,
    TResult Function(InvalidIsoFormat<T> value)? invalidIsoFormat,
    required TResult orElse(),
  }) {
    if (multilineString != null) {
      return multilineString(this);
    }
    return orElse();
  }
}

abstract class MultilineString<T> implements ValueFailure<T> {
  const factory MultilineString({required String failedValue}) =
      _$MultilineString<T>;

  String get failedValue => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $MultilineStringCopyWith<T, MultilineString<T>> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $InvalidLenghtStringCopyWith<T, $Res> {
  factory $InvalidLenghtStringCopyWith(InvalidLenghtString<T> value,
          $Res Function(InvalidLenghtString<T>) then) =
      _$InvalidLenghtStringCopyWithImpl<T, $Res>;
  $Res call({String failedValue});
}

/// @nodoc
class _$InvalidLenghtStringCopyWithImpl<T, $Res>
    extends _$ValueFailureCopyWithImpl<T, $Res>
    implements $InvalidLenghtStringCopyWith<T, $Res> {
  _$InvalidLenghtStringCopyWithImpl(InvalidLenghtString<T> _value,
      $Res Function(InvalidLenghtString<T>) _then)
      : super(_value, (v) => _then(v as InvalidLenghtString<T>));

  @override
  InvalidLenghtString<T> get _value => super._value as InvalidLenghtString<T>;

  @override
  $Res call({
    Object? failedValue = freezed,
  }) {
    return _then(InvalidLenghtString<T>(
      failedValue: failedValue == freezed
          ? _value.failedValue
          : failedValue // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$InvalidLenghtString<T> implements InvalidLenghtString<T> {
  const _$InvalidLenghtString({required this.failedValue});

  @override
  final String failedValue;

  @override
  String toString() {
    return 'ValueFailure<$T>.invalidLenghtString(failedValue: $failedValue)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other is InvalidLenghtString<T> &&
            (identical(other.failedValue, failedValue) ||
                const DeepCollectionEquality()
                    .equals(other.failedValue, failedValue)));
  }

  @override
  int get hashCode =>
      runtimeType.hashCode ^ const DeepCollectionEquality().hash(failedValue);

  @JsonKey(ignore: true)
  @override
  $InvalidLenghtStringCopyWith<T, InvalidLenghtString<T>> get copyWith =>
      _$InvalidLenghtStringCopyWithImpl<T, InvalidLenghtString<T>>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(T failedValue) empty,
    required TResult Function(String failedValue) multilineString,
    required TResult Function(String failedValue) invalidLenghtString,
    required TResult Function(String failedValue) invalidIsoFormat,
  }) {
    return invalidLenghtString(failedValue);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(T failedValue)? empty,
    TResult Function(String failedValue)? multilineString,
    TResult Function(String failedValue)? invalidLenghtString,
    TResult Function(String failedValue)? invalidIsoFormat,
    required TResult orElse(),
  }) {
    if (invalidLenghtString != null) {
      return invalidLenghtString(failedValue);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(Empty<T> value) empty,
    required TResult Function(MultilineString<T> value) multilineString,
    required TResult Function(InvalidLenghtString<T> value) invalidLenghtString,
    required TResult Function(InvalidIsoFormat<T> value) invalidIsoFormat,
  }) {
    return invalidLenghtString(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(Empty<T> value)? empty,
    TResult Function(MultilineString<T> value)? multilineString,
    TResult Function(InvalidLenghtString<T> value)? invalidLenghtString,
    TResult Function(InvalidIsoFormat<T> value)? invalidIsoFormat,
    required TResult orElse(),
  }) {
    if (invalidLenghtString != null) {
      return invalidLenghtString(this);
    }
    return orElse();
  }
}

abstract class InvalidLenghtString<T> implements ValueFailure<T> {
  const factory InvalidLenghtString({required String failedValue}) =
      _$InvalidLenghtString<T>;

  String get failedValue => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $InvalidLenghtStringCopyWith<T, InvalidLenghtString<T>> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $InvalidIsoFormatCopyWith<T, $Res> {
  factory $InvalidIsoFormatCopyWith(
          InvalidIsoFormat<T> value, $Res Function(InvalidIsoFormat<T>) then) =
      _$InvalidIsoFormatCopyWithImpl<T, $Res>;
  $Res call({String failedValue});
}

/// @nodoc
class _$InvalidIsoFormatCopyWithImpl<T, $Res>
    extends _$ValueFailureCopyWithImpl<T, $Res>
    implements $InvalidIsoFormatCopyWith<T, $Res> {
  _$InvalidIsoFormatCopyWithImpl(
      InvalidIsoFormat<T> _value, $Res Function(InvalidIsoFormat<T>) _then)
      : super(_value, (v) => _then(v as InvalidIsoFormat<T>));

  @override
  InvalidIsoFormat<T> get _value => super._value as InvalidIsoFormat<T>;

  @override
  $Res call({
    Object? failedValue = freezed,
  }) {
    return _then(InvalidIsoFormat<T>(
      failedValue: failedValue == freezed
          ? _value.failedValue
          : failedValue // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$InvalidIsoFormat<T> implements InvalidIsoFormat<T> {
  const _$InvalidIsoFormat({required this.failedValue});

  @override
  final String failedValue;

  @override
  String toString() {
    return 'ValueFailure<$T>.invalidIsoFormat(failedValue: $failedValue)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other is InvalidIsoFormat<T> &&
            (identical(other.failedValue, failedValue) ||
                const DeepCollectionEquality()
                    .equals(other.failedValue, failedValue)));
  }

  @override
  int get hashCode =>
      runtimeType.hashCode ^ const DeepCollectionEquality().hash(failedValue);

  @JsonKey(ignore: true)
  @override
  $InvalidIsoFormatCopyWith<T, InvalidIsoFormat<T>> get copyWith =>
      _$InvalidIsoFormatCopyWithImpl<T, InvalidIsoFormat<T>>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(T failedValue) empty,
    required TResult Function(String failedValue) multilineString,
    required TResult Function(String failedValue) invalidLenghtString,
    required TResult Function(String failedValue) invalidIsoFormat,
  }) {
    return invalidIsoFormat(failedValue);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(T failedValue)? empty,
    TResult Function(String failedValue)? multilineString,
    TResult Function(String failedValue)? invalidLenghtString,
    TResult Function(String failedValue)? invalidIsoFormat,
    required TResult orElse(),
  }) {
    if (invalidIsoFormat != null) {
      return invalidIsoFormat(failedValue);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(Empty<T> value) empty,
    required TResult Function(MultilineString<T> value) multilineString,
    required TResult Function(InvalidLenghtString<T> value) invalidLenghtString,
    required TResult Function(InvalidIsoFormat<T> value) invalidIsoFormat,
  }) {
    return invalidIsoFormat(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(Empty<T> value)? empty,
    TResult Function(MultilineString<T> value)? multilineString,
    TResult Function(InvalidLenghtString<T> value)? invalidLenghtString,
    TResult Function(InvalidIsoFormat<T> value)? invalidIsoFormat,
    required TResult orElse(),
  }) {
    if (invalidIsoFormat != null) {
      return invalidIsoFormat(this);
    }
    return orElse();
  }
}

abstract class InvalidIsoFormat<T> implements ValueFailure<T> {
  const factory InvalidIsoFormat({required String failedValue}) =
      _$InvalidIsoFormat<T>;

  String get failedValue => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $InvalidIsoFormatCopyWith<T, InvalidIsoFormat<T>> get copyWith =>
      throw _privateConstructorUsedError;
}
