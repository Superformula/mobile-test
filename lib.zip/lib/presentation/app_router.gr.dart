// GENERATED CODE - DO NOT MODIFY BY HAND

// **************************************************************************
// AutoRouteGenerator
// **************************************************************************

import 'package:auto_route/auto_route.dart' as _i1;
import 'package:flutter/material.dart' as _i2;

import 'core/home_screen.dart' as _i3;
import 'display_qr_code/display_qr_code.dart' as _i4;
import 'scan_qr_code/scan_qr_code.dart' as _i5;

class AppRouter extends _i1.RootStackRouter {
  AppRouter([_i2.GlobalKey<_i2.NavigatorState>? navigatorKey])
      : super(navigatorKey);

  @override
  final Map<String, _i1.PageFactory> pagesMap = {
    HomeScreenRoute.name: (routeData) => _i1.MaterialPageX<_i3.HomeScreen>(
        routeData: routeData,
        builder: (_) {
          return const _i3.HomeScreen();
        }),
    DisplayQrCodeScreenRoute.name: (routeData) =>
        _i1.MaterialPageX<_i4.DisplayQrCodeScreen>(
            routeData: routeData,
            builder: (_) {
              return const _i4.DisplayQrCodeScreen();
            }),
    ScanQrCodeScreenRoute.name: (routeData) =>
        _i1.MaterialPageX<_i5.ScanQrCodeScreen>(
            routeData: routeData,
            builder: (_) {
              return const _i5.ScanQrCodeScreen();
            })
  };

  @override
  List<_i1.RouteConfig> get routes => [
        _i1.RouteConfig(HomeScreenRoute.name, path: '/'),
        _i1.RouteConfig(DisplayQrCodeScreenRoute.name,
            path: '/display-qr-code-screen'),
        _i1.RouteConfig(ScanQrCodeScreenRoute.name,
            path: '/scan-qr-code-screen')
      ];
}

class HomeScreenRoute extends _i1.PageRouteInfo {
  const HomeScreenRoute() : super(name, path: '/');

  static const String name = 'HomeScreenRoute';
}

class DisplayQrCodeScreenRoute extends _i1.PageRouteInfo {
  const DisplayQrCodeScreenRoute()
      : super(name, path: '/display-qr-code-screen');

  static const String name = 'DisplayQrCodeScreenRoute';
}

class ScanQrCodeScreenRoute extends _i1.PageRouteInfo {
  const ScanQrCodeScreenRoute() : super(name, path: '/scan-qr-code-screen');

  static const String name = 'ScanQrCodeScreenRoute';
}
